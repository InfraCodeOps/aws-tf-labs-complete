#!/usr/bin/python
# Lab4 python program
def lambda_handler(event, context):
    print("Hello Lab4 App!");